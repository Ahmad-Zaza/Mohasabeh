@extends('crudbooster::admin_template')
@section('content')
<form method="get" action="{{url('modules/reports117')}}" class="print_display_none" >
<div class="col-lg-12">
<div class="col-lg-4">
اختر حساب الإقفال : 
    <select class="form-control" name="closing_account_type" id="select-closing_type" onchange="form.submit()">
    @foreach($closing_types as $type)
        <option value="{{$type->id}}" {{$closing_account_type==$type->id?'selected':''}} >{{$type->name_ar}}</option>
    @endforeach
    </select>
</div>
<div class="col-lg-3">
             <p  style="padding-top:7px;"></p>
            <button id="PrintReport" class="btn btn-success" onclick="window.print();" > طباعة <i class="fa fa-print"></i></button>
</div>
</div>
</form>
<hr>
<div class="print_display_none">
<br>
<br>
<br>
<br>
<br>
</div>
    <table id="tableId"  class="table table-hover table-striped table-bordered" >
        <caption> 
            <b> <center>  تفاصيل حساب الإقفال <br/> ({{$closing_account_type_name}}) </center> </b>
        </caption>
    <thead >
    <tr class="active">
        <th width="auto" ><a href=""><center> اسم الحساب</center></a></th>
        <th width="auto"><a href="" ><center> رصيد بالليرة السورية</center></a></th>
        <th width="auto"><a href=""><center> رصيد بالدولار</center></a></th>
        <th width="auto"><a href="" ><center> رصيد باليور</center></a></th>
    </tr>
    </thead>
    <tbody class="ui-sortable"  align="center">
    @if($data != null)
    @foreach($data as $item)
        <tr>
            <td>{{$item['account_name']}}</td>
            <td>{{number_format($item['sp_balance'],2)}}</td>
            <td>{{number_format($item['dollar_balance'],2)}}</td>
            <td>{{number_format($item['euro_balance'],2)}}</td>
        </tr>
    @endforeach
        @if(count($data) > 0)   
            <tr id="trTotal">
                <td align="center" bgcolor="#00ff7f" >
                    اجمالي الرصيد
                </td>
                <td bgcolor="#7fff00">{{number_format($SP_balance,2)}}</td>
                <td bgcolor="#7fff00">{{number_format($dollar_balance,2)}}</td>
                <td bgcolor="#7fff00">{{number_format($euro_balance,2)}}</td>
            </tr>
            @else
            <tr id="trTotal">
                <td colspan='4' style="text-align:center;"> لا توجد  نتائج</td>
            </tr>
        @endif
    @endif

    </tbody>
</table>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script type="text/javascript">
        $('#select-closing_type').select2();

    
        
    </script>
@endsection
