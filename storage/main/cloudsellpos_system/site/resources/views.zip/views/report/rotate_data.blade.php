@extends('crudbooster::admin_template')
@section('content')

<br/>
<br/>
<br/>
<br/>
<div class="col-md-12">
    <div class="callout callout-info waiting-msg hidden">
                    <h4>     رجاءاً ، انتظر</h4>
                    <p>العملية تأخذ بعض الوقت . <i class="fa fa-refresh fa-spin"></i></p>
                    
    </div>
</div>
<div class="col-md-12">
          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab" aria-expanded="true">الأرصدة الإفتتاحية للسنة المالية الجديدة</a></li>
              <li class=""><a href="#tab_2" data-toggle="tab" aria-expanded="false">بضاعة أول المدة للسنة المالية الجديدة</a></li>
              <li class=""><a href="#tab_3" data-toggle="tab" aria-expanded="false">أرباح وخسائر</a></li>
              
              <li class="pull-left"><button id="rotate_data" class="btn btn-primary" > تدوير الحسابات <i class="fa fa-gear "></i></button></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
               
            <div class="box">
                    <!--div class="box-header">
                        <h3 class="box-title"></h3>
                    </div-->
                    <!-- /.box-header -->
                <div class="box-body">
                    <div id="form-table" class="dataTables_wrapper form-inline dt-bootstrap">
                                
                        <div class="row">
                            <div class="col-sm-12">
                            <table id="example1" class="table table-bordered table-striped dataTable text-center" role="grid" aria-describedby="example1_info">
                                <thead>
                                <tr role="row">
                                    <th style="text-align:right" > اسم الحساب</th>
                                    <th > رصيد بالليرة السورية</th>
                                    <th > رصيد بالدولار</th>
                                    <th > رصيد باليورو</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if($data != null)
                                @foreach($data as $item)
                                    <tr>
                                        <td style="text-align:right">{{$item['account_name']}}</td>
                                        <td>{{number_format($item['sp_balance'],2)}}</td>
                                        <td>{{number_format($item['dollar_balance'],2)}}</td>
                                        <td>{{number_format($item['euro_balance'],2)}}</td>
                                    </tr>
                                @endforeach
                                    @if(count($data) > 0)   
                                        <tr id="trTotal">
                                            <td style="text-align:right" bgcolor="#00ff7f" >
                                                اجمالي الرصيد
                                            </td>
                                            <td bgcolor="#7fff00">{{number_format($SP_balance,2)}}</td>
                                            <td bgcolor="#7fff00">{{number_format($dollar_balance,2)}}</td>
                                            <td bgcolor="#7fff00">{{number_format($euro_balance,2)}}</td>
                                        </tr>
                                        @else
                                        <tr id="trTotal">
                                            <td colspan='4' > لا توجد  نتائج</td>
                                        </tr>
                                    @endif
                                @endif
                                </tbody>
                                <tfoot>
                                    <tr role="row">
                                        <th > اسم الحساب</th>
                                        <th > رصيد بالليرة السورية</th>
                                        <th > رصيد بالدولار</th>
                                        <th >رصيد باليورو</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
            
                    </div>
                </div>
                            <!-- /.box-body -->
            </div>
                
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                <!-- start Table -->
                    <div class="box">
                        <!--div class="box-header">
                            <h3 class="box-title"></h3>
                        </div-->
                        <!-- /.box-header -->
                    <div class="box-body">
                        <div id="form-table" class="dataTables_wrapper form-inline dt-bootstrap">
                                    
                            <div class="row">
                                <div class="col-sm-12">
                                <table id="example1" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                                    <thead>
                                        <tr role="row">
                                            <th >المادة</th>
                                            <th >المستودع</th>
                                            <th >العدد</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    @if($inventories_data != null)
                                        @foreach($inventories_data as $inv_data)
                                            <tr>
                                                <td>{{$inv_data->nameAr}}</td>
                                                <td>{{$inv_data->sourceInventory}}</td>
                                                <td>{{($inv_data->item_in - ($inv_data->item_out == null?0:$inv_data->item_out))}}</td>
                                                
                                            </tr>
                                        @endforeach
                                            @if(count($inventories_data) < 0)   
                                                <tr id="trTotal">
                                                    <td colspan='3' > لا توجد  نتائج</td>
                                                </tr>
                                            @endif
                                    @endif
                                    </tbody>
                                    <tfoot>
                                        <tr role="row">
                                            <th >المادة</th>
                                            <th >المستودع</th>
                                            <th >العدد</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                
                        </div>
                    </div>
                                <!-- /.box-body -->
                </div>
                <!-- end Table -->
                
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                   : الأرباح والخسائر
                  {{$profits_and_loss}}
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>




<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <script type="text/javascript">
       

        $('#rotate_data').click(function(){
            
        swal({
                title: 'هل أنت متأكد؟',
                text: "خلال تدوير الحسابات للسنة مالية جديدة ستفقد إمكانية تعديل على  الفواتير والسندات السابقة، قم بالضغط على متابعة للقيام بعملية التدوير",
                type:'info',
                showCancelButton:true,
                allowOutsideClick:true,
                confirmButtonColor: '#DD6B55',
                confirmButtonText: 'متابعة',
                cancelButtonText: 'إلغاء',
                closeOnConfirm: false
                }, function(){
                    $('#rotate_data i').addClass('fa-spin');
                    $('#rotate_data').addClass('disabled');
                    $('.waiting-msg').removeClass('hidden');
                    swal.close();
                    $.get('/rotate_data',function(res){
                      //console.log(res);
                      $('#rotate_data i').removeClass('fa-spin');
                      $('.waiting-msg').addClass('hidden');
                      location.href = 'http://127.0.0.1:8000/modules';
		            })
                
            });

            
        });
        
    </script>
@endsection
