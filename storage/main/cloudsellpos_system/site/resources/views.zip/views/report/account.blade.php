@extends('crudbooster::admin_template')
@section('content')
<form method="get" action="{{url('modules/reports99')}}" class="print_display_none">
<div class="col-lg-12">
<div class="col-lg-4">
الحساب :
    <select class="form-control" name="account_id" id="select-account">
    <option value="-1">أختر الحساب</option>
    @foreach($accounts as $item)
        <option value="{{$item->id}}" {{$account_id==$item->id?'selected':''}} >{{$item->name_ar}}</option>
    @endforeach
    </select>
</div>

    <div class="col-lg-4">
    المندوب :
        <select class="form-control" name="delegate_id" id="select-delegate">

            <option value="-1">أختر المندوب</option>
            @foreach($delegates as $item)
                <option value="{{$item->id}}" {{$delegate_id==$item->id?'selected':''}} >{{$item->name}}</option>
            @endforeach
        </select>
    </div>

    <div class="col-lg-4">{{trans('crudbooster.From')}} : {{$from_date}}

        <input type="date" name="from_date" id="from_date" class="form-control" value="{{$from_date}}">
    </div>

    <div class="col-lg-4">{{trans('crudbooster.To')}} : {{$to_date}}

        <input type="date" name="to_date" id="to_date" class="form-control" value="{{$to_date}}">
    </div>
    <div class="col-lg-4">
    العملة :
        <select class="form-control" name="currency_id" id="select-currency">
            <option value="-1">اختر العملة</option>
            @foreach($currencies as $item)
                <option value="{{$item->id}}" {{$currency_id==$item->id?'selected':''}}>{{$item->name_ar}}</option>
            @endforeach
        </select>
    </div>


<div class="col-lg-3">
    <br>
    <input type="submit" class="btn btn-primary" value="{{trans('crudbooster.Search')}}">
    <button id="PrintReport" class="btn btn-success" onclick="window.print();" > طباعة <i class="fa fa-print"></i></button>
</div>
</div>
</form>
<hr>
<div class="print_display_none">
<br>
<br>
<br>
<br>
</div>
@if($currency_id != -1)
<table id="tableId" class="table table-hover table-striped table-bordered">
    <caption> <b> <center> تفاصيل الحساب</center> </b></caption>
    <thead>
        <tr class="active">
        <th class="print_display_none"></th>
            <th width="auto"><a href="" >الأسم </a></th>
            <th width="auto"><a href="" >دائن </a></th>
            <th width="auto"><a href="" >مدين </a></th>
            <th width="auto"><a href="" >التاريخ</a></th>
            <th width="auto"><a href="" >البيان </a></th>
            <th width="auto"><a href="" >العملة </a></th>
            <th width="auto"><a href="" >الرصيد</a></th>
        </tr>
    </thead>
    <tbody class="ui-sortable">
    @php 
    $prevBalance = 0;
    @endphp    
    @foreach($data as $item)
        @php
        $paid = $item->paid_amount;
        $received = $item->received_amount;
        $prevBalance = $prevBalance + ($received - $paid);
        @endphp
    <tr>
    <td class="print_display_none"></td>

        <td>
            {{$item->name}}
        </td>

        <td>
            {{($paid)?number_format($paid,2):0}}      
        </td>


        <td>
        {{($received)?number_format($received,2):0}}      

        </td>

       
        <td>
            {{$item->date}}      
        </td>
        <td>
            {{$item->narration}}      
        </td>
        <td>
            {{$item->currency}}
        </td>
        <td >
            {{number_format($prevBalance,2)}}
        </td>
    </tr>

    @endforeach


        
    </tbody>
</table>
@else
<table id="tableId2" class="table table-hover table-striped table-bordered">
    <caption> <b> <center> تفاصيل الحساب</center> </b></caption>
    <thead>
        <tr class="active">
        <th class="print_display_none"></th>
            <th width="auto"><a href="" >الأسم </a></th>
            <th width="auto"><a href="" >دائن </a></th>
            <th width="auto"><a href="" >مدين </a></th>
            <th width="auto"><a href="" >التاريخ</a></th>
            <th width="auto"><a href="" >البيان </a></th>
            <th width="auto"><a href="" >العملة </a></th>
            <th width="auto"><a href="" > الرصيد (اليورو) </a></th>
            <th width="auto"><a href="" > الرصيد (دولار) </a></th>
            <th width="auto"><a href="" > (ل.س)الرصيد</a></th>
        </tr>
    </thead>
    
    <tbody class="ui-sortable">
    @php
        $final_SP_balance = 0;
        $final_dollar_balance = 0;
        $final_euro_balance = 0;
    @endphp    
   
    @foreach($data as $item)
        @php
            $paid = $item->paid_amount;
            $received = $item->received_amount;

            if($item->currency_id == 1){
                $final_SP_balance = $final_SP_balance + ($received - $paid) ;
            }
            if($item->currency_id == 2){
                $final_dollar_balance = $final_dollar_balance + ($received - $paid) ;
            }
            if($item->currency_id == 3){
                $final_euro_balance = $final_euro_balance + ($received - $paid) ;
            }
        @endphp
    <tr data-currency="{{$item->currency_id}}">
    <td class="print_display_none"></td>

        <td>
            {{$item->name}}
        </td>

        <td>
            {{($item->paid_amount)?number_format($item->paid_amount,2):0}}      
        </td>


        <td>
        {{($item->received_amount)?number_format($item->received_amount,2):0}}      

        </td>

       
        <td>
            {{$item->date}}      
        </td>
        <td>
            {{$item->narration}}      
        </td>
        <td>
            {{$item->currency}}
        </td>
        <td >
            {{number_format($final_euro_balance,2)}}
        </td>
        <td >
            {{number_format($final_dollar_balance,2)}}
        </td>
        <td >
            {{number_format($final_SP_balance,2)}}
        </td>
    </tr>

    @endforeach


        
    </tbody>
</table>
<div class='row'>
    <div class="col-sm-4 {{ ($account_id == config('setting.Dollar_Box_Account') or ($account_id == config('setting.Euro_Box_Account')))?'hidden':''}} {{ $account_id == config('setting.Syrian_Pound_Box_Account')?'col-sm-offset-4':''}} "  >
        <div class="border-box">
            <div class="small-box bg-red	">
                <div class="inner inner-box">
                    <h3 id="final_SP_balance"> {{number_format($final_SP_balance,2)}}	</h3>
                    <p>رصيد الحساب بالليرة السورية	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag	"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$_REQUEST['account_id']?>&delegate_id=<?=$_REQUEST['delegate_id']?>&from_date=<?=$_REQUEST['from_date']?>&to_date=<?=$_REQUEST['to_date']?>&currency_id=1" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-sm-4 {{ ($account_id == config('setting.Syrian_Pound_Box_Account') or ($account_id == config('setting.Euro_Box_Account')))?'hidden':''}} {{ $account_id == config('setting.Dollar_Box_Account')?'col-sm-offset-4':''}}">
    <div class="border-box">
            <div class="small-box bg-green	">
                <div class="inner inner-box">
                    <h3 id="final_dollar_balance">  {{number_format($final_dollar_balance,2)}}	</h3>
                    <p>رصيد الحساب  بالدولار	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-social-usd"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$_REQUEST['account_id']?>&delegate_id=<?=$_REQUEST['delegate_id']?>&from_date=<?=$_REQUEST['from_date']?>&to_date=<?=$_REQUEST['to_date']?>&currency_id=2" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-sm-4 {{ ($account_id == config('setting.Syrian_Pound_Box_Account') or ($account_id == config('setting.Dollar_Box_Account')))?'hidden':''}} {{ $account_id == config('setting.Euro_Box_Account')?'col-sm-offset-4':''}}">
    <div class="border-box">
            <div class="small-box bg-aqua	">
                <div class="inner inner-box">
                    <h3 id="final_euro_balance">{{number_format($final_euro_balance,2)}}	</h3>
                    <p>رصيد الحساب  باليورو	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-social-euro"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$_REQUEST['account_id']?>&delegate_id=<?=$_REQUEST['delegate_id']?>&from_date=<?=$_REQUEST['from_date']?>&to_date=<?=$_REQUEST['to_date']?>&currency_id=3" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    
</div>
@endif
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script type="text/javascript">
        $('#select-account').select2();
        $('#select-delegate').select2();
        $('#select-currency').select2();

    

    </script>
@endsection
