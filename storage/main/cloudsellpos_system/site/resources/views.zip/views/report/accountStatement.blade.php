@extends('crudbooster::admin_template')
@section('content')
    <form method="get" action="{{url('modules/accountstatement')}}" class="print_display_none">
        <div class="col-lg-12">
            <div class="col-lg-4">
            الحساب :
                <select class="form-control" name="person_id" id="select_customer">
                    <option value="-1">أختر الحساب</option>
                    @foreach($persons as $item)
                        <option value="{{$item->id}}" {{$person_id==$item->id?'selected':''}} >{{$item->name_ar}}</option>
                    @endforeach
                </select>
            </div>

            <div class="col-lg-4">
            العملة:
                <select class="form-control" name="currency_id" id="select_currency">
                    <option value="-1">اختر العملة</option>
                    @foreach($currencies as $item)
                        <option value="{{$item->id}}" {{$currency_id==$item->id?'selected':''}}>{{$item->name_ar}}</option>
                    @endforeach
                </select>
            </div>

            <div class="col-lg-4">{{trans('crudbooster.From')}} : {{$from_date}}

                <input type="date" name="from_date" id="from_date" class="form-control" value="{{$from_date}}">
            </div>

            <div class="col-lg-4">{{trans('crudbooster.To')}} : {{$to_date}}

                <input type="date" name="to_date" id="to_date" class="form-control" value="{{$to_date}}">
            </div>


            <div class="col-lg-3">
                <br>
                <input type="submit" class="btn btn-primary" value="{{trans('crudbooster.Search')}}" id>
                <button id="PrintReport" class="btn btn-success" onclick="window.print();" > طباعة <i class="fa fa-print"></i></button>
            </div>
        </div>
    </form>
<hr>
<div class="print_display_none">
    <br>
    <br>
    <br>
    <br>
</div>


    <table id="tableId"  class="table table-hover table-striped table-bordered" >
        <caption> <b> <center> تفاصيل الحساب</center> </b></caption>
    <thead >
    <tr class="active">
        <th style="display:none;"></th>
        <th style="display:none;"></th>
        <th style="display:none;"></th>
        <th width="auto" ><a href="" title="Click to sort ascending"><center> التاريخ</center></a></th>
        <th width="auto"><a href="" title="Click to sort ascending"><center> البيان</center></a></th>
        <th width="auto"><a href="" title="Click to sort ascending"><center> مدين</center></a></th>
        <th width="auto"><a href="" title="Click to sort ascending"><center> دائن</center></a></th>
        <th width="auto"><a href="" title="Click to sort ascending"><center> الحالة</center></a></th>
        <th width="auto"><a href="" title="Click to sort ascending"><center>Action</center></a></th>
        {{--            <th width="auto"><a href="" title="Click to sort ascending">Source Inventory &nbsp; <i class="fa fa-sort"></i></a></th>--}}
        {{--            <th width="auto"><a href="" title="Click to sort ascending">Destination Inventory &nbsp; <i class="fa fa-sort"></i></a></th>--}}
    </tr>
    </thead>
    <tbody class="ui-sortable"  align="center">
    @if($data != null)
    @php
    $debitval = 0;
    $creditval = 0;
    $total=0;
    @endphp
    @foreach($data as $item)
        <tr id="{{$item->billId}}">
            <td style="display:none;">{{$item->billTypeId}}</td>
            <td style="display:none;">{{$item->entryBaseId}}</td>
            <td style="display:none;">{{$item->billId}}</td>
            <td>
                {{$item->entryDate}}
            </td>
            <td>
                {{$item->entryNarration}} / {{$item->billTypeName}} / {{$item->billCode}}
            </td>
            <td>
            @php 
                $debitval+= ($item->debit?$item->debit:0);
                $creditval+= ($item->credit?$item->credit:0);
            @endphp
                {{$item->debit?number_format($item->debit,2):0}}
            </td>
            <td>
                {{$item->credit?number_format($item->credit,2):0}}
            </td>
            <td>
                {{($item->credit != NULL && $item->billTypeId == 2) ? 'تم دفع قيمة نقداً':''}}
                {{($item->debit != NULL  && $item->billTypeId == 2) ? 'قيمة الفاتورة':''}}

                {{($item->debit != NULL && $item->billTypeId == 1) ? 'تم دفع قيمة نقداً':''}}
                {{($item->credit != NULL  && $item->billTypeId == 1) ? 'قيمة الفاتورة':''}}
            </td>
            <td>
                <button type="button" class="btn btn-light-blue btn-md btn-edit print_display_none" id="edit" data-id="{{$item->billId}}" >الذهاب إلى المصدر</button>


            </td>

        </tr>

    @endforeach
        @if(count($data) > 0)   
            <tr id="trTotal">
                <td colspan="2" align="center" >
                    الرصيد
                </td>
                <td id="debit">
                    <span id="debitval">{{number_format($debitval,2)}}</span>
                    
                </td>
                <td id="credit">
                    <span id="creditval">{{number_format($creditval,2)}}</span>
                    
                </td>
                <td></td>
                <td id="total">
                    <span class="badge btn-primary" style="padding:10px;" id="totalval" title="مدين للشركة بهذا المبلغ">{{number_format($debitval-$creditval,2)}}</span>
                   
                </td>
            </tr>
            @else
            <tr id="trTotal">
                <td colspan='6' style="text-align:center;"> لا توجد  مناقلات مالية خاصة بهذا الحساب</td>
            </tr>
        @endif
    @endif

    </tbody>



</table>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script   type="text/javascript">
        $('#select_customer').select2();
        $('#select_currency').select2();

            

        $('#select_customer').change(function(){

            var id = $(this).val();

            document.getElementById('select_currency').options.length = 0;
            $.post('/reports/getDealCurrencies/'+id,function(res){
                console.log(res);
                if (res.length != 0) {
                    res.forEach(element => {
                        $('#select_currency').append(new Option(element.name_ar, element.id));


                    });
                }
                else {
                    $('#select_currency').append(new Option('لا يوجد عملات', '-1'));

                }
            })
        })


        // $('#val').val(sumVal);
        $('#tableId').delegate('.btn-edit','click',function() {

           var value = $(this).data('id');
            var currentRow=$(this).closest("tr");
            var type= currentRow.find("td:eq(0)").text(); // get current row 1st TD value
            var entryBaseId=currentRow.find("td:eq(1)").text(); // get current row 1st TD value
           //  var billId=currentRow.find("td:eq(0)").text(); // get current row 1st TD value

            var base_url = window.location.origin;

            if(type==1)
            {
                window.location.href=base_url +"/modules/bills_purchase_invoice/detail/"+value;

            }

            if(type == 2)
            {
                window.location.href=base_url +"/modules/bills_sales_invoice/detail/"+value;

            }
            if(type==3)
            {
                window.location.href=base_url +"/modules/bills_purchase_return_invoice/detail/"+value;

            }
            if(type==4)
            {
                window.location.href=base_url +"/modules/bills_sales_return_invoice/detail/"+value;

            }

            if (value == 0) {
                window.location.href = base_url + "/modules/entry_base/detail/" + entryBaseId;

            }


            })
    </script>
@stop
