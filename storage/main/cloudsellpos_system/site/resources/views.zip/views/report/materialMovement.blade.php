@extends('crudbooster::admin_template')
@section('content')
<form method="get" action="{{url('modules/item_tracking102')}}" class="print_display_none">
<div class="col-lg-12">
<div class="col-lg-4">
المستودع:
    <select class="form-control" name="inventory_id" id="select-inventory">
    <option value="-1">أختر المستودع</option>
    @foreach($inventories as $item)
        <option value="{{$item->id}}" {{$inventory_id==$item->id?'selected':''}} >{{$item->name_ar}}</option>
    @endforeach
    </select>
</div>

<div class="col-lg-4">
المادة:
    <select class="form-control" name="item_id" id="select-item">
    <option value="-1">أختر المادة</option>
    @foreach($items as $item)
        <option value="{{$item->id}}" {{$item_id==$item->id?'selected':''}}>{{$item->name_ar}}</option>
    @endforeach
    </select>
</div>
    <div class="col-lg-4">
    العملية:
        <select class="form-control" name="type_id" id="select-operation">
            <option value="-1">أختر نوع العملية</option>
            @foreach($types as $item)
                <option value="{{$item->id}}" {{$type_id==$item->id?'selected':''}} >{{$item->name_ar}}</option>
            @endforeach
        </select>
    </div>
    <br>
    <br>
    <br>
        <div class="col-lg-4">

        {{trans('crudbooster.From')}} : <input type="date" name="from_date" id="date" class="form-control" value="{{$from_date}}">
        </div>

    <div class="col-lg-4">
    {{trans('crudbooster.To')}} :   <input type="date" name="to_date" id="date" class="form-control" value="{{$to_date}}">
    </div>
<br>
    <div class="col-lg-3">
    <input type="submit" class="btn btn-primary" value="{{trans('crudbooster.Search')}}">
    <button id="PrintReport" class="btn btn-success" onclick="window.print();" > طباعة <i class="fa fa-print"></i></button>
</div>
</div>
</form>
<hr>
<div class="print_display_none">
<br>
<br>
<br>
<br>
<br>
</div>
<table id="tableId" class="table table-hover table-striped table-bordered">
    <caption> <b> <center>حركة المواد</center> </b></caption>
    <thead>
    <tr class="active">
        <th style="display:none;"></th>
        <th style="display:none;"></th>
        <th style="display:none;"></th>
        <th width="auto"><a href="" title="Click to sort ascending">التاريخ</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">الرمز</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">اسم المادة</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">نوع الوثيقة</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">المستودع</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">العملية</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">الوحدة</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">العدد</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">سعر الوحدة</a></th>

        <th width="auto"><a href="" title="Click to sort ascending">الأجمالي</a></th>
        <th width="auto"><a href="" title="Click to sort ascending">الرصيد</a></th>
        <th width="auto" class="print_display_none"><a href="" title="Click to sort ascending" >Action</a></th>
        {{--            <th width="auto"><a href="" title="Click to sort ascending">Source Inventory &nbsp; <i class="fa fa-sort"></i></a></th>--}}
        {{--            <th width="auto"><a href="" title="Click to sort ascending">Destination Inventory &nbsp; <i class="fa fa-sort"></i></a></th>--}}
    </tr>
    </thead>
    <tbody class="ui-sortable">

    @foreach($data as $item)
        <tr id="{{$item->billId}}">
            <td style="display:none;">{{$item->typeEn}}</td>
            <td style="display:none;">{{$item->trackingId}}</td>
            <td style="display:none;">{{$item->billId}}</td>
            <td>
                {{$item->trackingDate}}
            </td>
            <td>
                {{$item->trackingName}}
            </td>
            <td>
                {{$item->itemNameAr}}
            </td>
            <td>
                {{$item->typeName}}
            </td>
            <td>
                {{$item->sourceInventory}}
            </td>

            <td>
                {{$item->trackingOperation}}
            </td>


            <td>
                {{$item->itemUnitNameAr}}

            </td>
            <td>
                {{$item->trackingQuantity}}


            </td>

            <td>
                <?php
                    if($item->itemPrice == null){ // عندما تكون المناقلة بضاعة أول مدة يأتي السعر null 
                        $item->itemPrice=$item->itemOrginalPrice;
                    }
                ?>
                {{number_format($item->itemPrice,2)}}
            </td>


            <td>

                <?php
                  $val = abs((($item->itemPrice)?$item->itemPrice:0) * (($item->trackingQuantity)?$item->trackingQuantity:0));
                ?>
                {{($val != 0)?number_format($val,2):''}}


            </td>
            <td>
                <?php
                  $val2 = abs((($item->itemPrice)?$item->itemPrice:0) * (($item->trackingQuantity)?$item->trackingQuantity:0));
                ?>
                {{($val2 != 0)?number_format($val2,2):''}}
                


            </td>
            <td class="print_display_none">
                <button type="button" class="btn btn-light-blue btn-md btn-edit" id="edit" data-id="{{$item->trackingId}}" >الذهاب إلى المصدر</button>


            </td>

        </tr>

    @endforeach



    </tbody>



</table>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script   type="text/javascript">
        $('#select-inventory').select2();
        $('#select-item').select2();
        $('#select-operation').select2();

        $('#tableId').delegate('.btn-edit','click',function() {

           // var value = $(this).data('id');
            var currentRow=$(this).closest("tr");
            var type=currentRow.find("td:eq(0)").text(); // get current row 1st TD value
            var trackingId=currentRow.find("td:eq(1)").text(); // get current row 1st TD value
            var billId=currentRow.find("td:eq(2)").text(); // get current row 1st TD value

            var base_url = window.location.origin;

            if(type=="bill")
            {
                window.location.href=base_url +"/modules/bills_purchase_invoice/detail/"+billId;

            }
            if(type == "inventory beginning")
            {
                window.location.href=base_url +"/modules/item_tracking100/detail/"+trackingId;

            }
            if(type == "invoice")
            {
                window.location.href=base_url +"/modules/bills_sales_invoice/detail/"+billId;

            }
            if(type=="Purchase return")
            {
                window.location.href=base_url +"/modules/bills_purchase_return_invoice/detail/"+billId;

            }
            if(type=="Sales return")
            {
                window.location.href=base_url +"/modules/bills_sales_return_invoice/detail/"+billId;

            }
            if(type == "Transfer")
            {
                window.location.href=base_url +"/modules/item_tracking101/detail/"+trackingId;

            }

        })
    </script>
@stop
