@extends('crudbooster::admin_template')
@section('content')
@php
    $balance_sp=0;
    $balance_dollar=0;
    $balance_euro=0;
    foreach($salesman_balance as $bal){
        if($bal->currency_id == 1){
            $balance_sp =$bal->curr_balance; 
        }
        if($bal->currency_id == 2){
            $balance_dollar =$bal->curr_balance; 
        }
        if($bal->currency_id == 3){
            $balance_euro =$bal->curr_balance; 
        }
    }
@endphp
<div class='row'>
    <div class="col-sm-12">
        <h3>   صندوق المندوب  </h3>
        <hr style="border:1px solid white;"/>
    </div>
    <div class="col-sm-4 "  >
        <div class="border-box">
            <div class="small-box bg-red	">
                <div class="inner inner-box">
                    <h3 id="final_SP_balance"> {{number_format($balance_sp,2)}}	</h3>
                    <p>رصيد الحساب بالليرة السورية	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-bag	"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$salesman_account_id?>&currency_id=1" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-sm-4 ">
    <div class="border-box">
            <div class="small-box bg-green	">
                <div class="inner inner-box">
                    <h3 id="final_dollar_balance">  {{number_format($balance_dollar,2)}}	</h3>
                    <p>رصيد الحساب  بالدولار	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-social-usd"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$salesman_account_id?>&currency_id=2" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-sm-4 ">
    <div class="border-box">
            <div class="small-box bg-aqua	">
                <div class="inner inner-box">
                    <h3 id="final_euro_balance"> {{number_format($balance_euro,2)}}	</h3>
                    <p>رصيد الحساب  باليورو	</p>
                </div>
                <div class="icon">
                    <i class="ion ion-social-euro"></i>
                </div>
                <a href="/modules/reports99?account_id=<?=$salesman_account_id?>&currency_id=3" class="small-box-footer">شاهد التفاصيل <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>
    
</div>
<div class='row'>
    <div class="col-sm-12">
        <h3> أرصدة الزبائن  </h3>
        <hr style="border:1px solid white;"/>
    </div>
    <!----- start Table ------>
    <div class="col-sm-12">

                    <div id="form-table" class="dataTables_wrapper form-inline dt-bootstrap">
                                
                        <div class="row">
                            <div class="col-sm-12">
                                <table id="example1" class="table table-bordered table-striped dataTable text-center" role="grid" aria-describedby="example1_info">
                                    <thead>
                                    <tr role="row">
                                        <th style="text-align:right" > اسم الحساب</th>
                                        <th > رصيد بالليرة السورية</th>
                                        <th > رصيد بالدولار</th>
                                        <th > رصيد باليورو</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if($customers_balances != null)
                                    @foreach($customers_balances as $item)
                                        <tr>
                                            <td style="text-align:right; padding-right:30px;">{{$item['account_name']}}</td>
                                            <td>{{$item['sp_balance']}}</td>
                                            <td>{{$item['dollar_balance']}}</td>
                                            <td>{{$item['euro_balance']}}</td>
                                        </tr>
                                    @endforeach
                                        @if(count($customers_balances) <= 0) 
                                            <tr id="trTotal">
                                                <td colspan='4' > لا توجد  نتائج</td>
                                            </tr>
                                        @endif
                                    @endif
                                    </tbody>
                                    
                                </table>
                            </div>
                        </div>
            
                    </div>         
               
    </div>       
    <!----- End table -------->

</div>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">


    </script>
@endsection
